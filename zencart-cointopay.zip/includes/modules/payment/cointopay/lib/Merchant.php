<?php
namespace cointopay;

class Merchant {}
