<?php

// Cointopay Class
require(dirname(__FILE__) . '/lib/Cointopay.php');

// Merchant Class
require(dirname(__FILE__) . '/lib/Merchant.php');

// Order Class
require(dirname(__FILE__) . '/lib/Merchant/Order.php');
