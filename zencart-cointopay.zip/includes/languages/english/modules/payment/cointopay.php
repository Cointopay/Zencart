<?php

define('MODULE_PAYMENT_COINTOPAY_TEXT_TITLE', 'Cointopay International');
define('MODULE_PAYMENT_COINTOPAY_TEXT_DESCRIPTION', 'Cointopay International');
define('MODULE_PAYMENT_COINTOPAY_TEXT_CHECKOUT', 'Cointopay International');
